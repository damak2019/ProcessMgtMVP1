package com.bnpparibas.ism.processmgt.domain;

public enum ProcessType {
        ARCHITECTURE,
        QUALITY;
}
