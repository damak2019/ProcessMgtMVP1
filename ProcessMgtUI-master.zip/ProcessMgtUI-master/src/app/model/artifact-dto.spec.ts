import { ArtifactDTO } from './artifact-dto';

describe('ArtifactDTO', () => {
  it('should create an instance', () => {
    expect(new ArtifactDTO()).toBeTruthy();
  });
});
