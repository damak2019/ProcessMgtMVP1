import { ProcessActivityDTO } from './process-activity-dto';

describe('ProcessActivityDTO', () => {
  it('should create an instance', () => {
    expect(new ProcessActivityDTO()).toBeTruthy();
  });
});
