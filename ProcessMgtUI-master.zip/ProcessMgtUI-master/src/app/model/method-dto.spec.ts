import { MethodDTO } from './method-dto';

describe('MethodDTO', () => {
  it('should create an instance', () => {
    expect(new MethodDTO()).toBeTruthy();
  });
});
